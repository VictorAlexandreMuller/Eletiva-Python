# 4: Contagem de 1 a 10
for i in range(1, 11):
    print(i)
